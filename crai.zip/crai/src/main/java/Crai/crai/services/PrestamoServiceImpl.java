package Crai.crai.services;

import Crai.crai.dto.DetallePrestamoDTO;
import Crai.crai.dto.PrestamoDTO;
import Crai.crai.dto.PrestamoRegistroDTO;
import Crai.crai.entity.DetallePrestamo;
import Crai.crai.entity.Ejemplar;
import Crai.crai.entity.Prestamo;
import Crai.crai.entity.Usuario;
import Crai.crai.exception.BusinessRuleException;
import Crai.crai.exception.ResourceNotFoundException;
import Crai.crai.repository.DetallePrestamoRepository;
import Crai.crai.repository.EjemplarRepository;
import Crai.crai.repository.PrestamoRepository;
import Crai.crai.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PrestamoServiceImpl implements IPrestamoService {
    private static final String ACTIVO = "A";
    private static final String DEVUELTO = "D";
    private static final int MAX_PRESTAMOS_ACTIVOS = 3;
    private static final int MAX_DIAS_RENOVACION = 15;

    private final PrestamoRepository prestamoRepository;
    private final EjemplarRepository ejemplarRepository;
    private final DetallePrestamoRepository detallePrestamoRepository;
    private final UsuarioRepository usuarioRepository;

    public PrestamoServiceImpl(PrestamoRepository prestamoRepository, EjemplarRepository ejemplarRepository,
                               DetallePrestamoRepository detallePrestamoRepository, UsuarioRepository usuarioRepository) {
        this.prestamoRepository = prestamoRepository;
        this.ejemplarRepository = ejemplarRepository;
        this.detallePrestamoRepository = detallePrestamoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    @Transactional
    public PrestamoDTO registrar(PrestamoRegistroDTO dto) {
        Usuario u = usuarioRepository.findByCodigoUni(dto.codigoUni())
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con codigo:" + dto.codigoUni()));
        Ejemplar ej = ejemplarRepository.findById(dto.idEjemplar())
                .orElseThrow(() -> new ResourceNotFoundException("Ejemplar no encontrado con id:" + dto.idEjemplar()));

        // reglas de negocio
        if (u.getEstadoAcceso() == null || u.getEstadoAcceso() != 1) {
            throw new BusinessRuleException("El usuario no tiene acceso habilitado para pedir prestamos");
        }
        Long idPersona = u.getIdPersona();
        LocalDateTime ahora = LocalDateTime.now();
        if (prestamoRepository.existsByPersonaIdPersonaAndEstadoAndFechaVencimientoBefore(idPersona, ACTIVO, ahora)) {
            throw new BusinessRuleException("El usuario tiene prestamos vencidos pendientes de devolucion");
        }
        if (prestamoRepository.countByPersonaIdPersonaAndEstado(idPersona, ACTIVO) >= MAX_PRESTAMOS_ACTIVOS) {
            throw new BusinessRuleException("El usuario alcanzo el maximo de " + MAX_PRESTAMOS_ACTIVOS + " prestamos activos");
        }
        if (!"DISPONIBLE".equalsIgnoreCase(ej.getEstado())) {
            throw new BusinessRuleException("El ejemplar no esta disponible para prestamo");
        }

        Prestamo p = new Prestamo();
        p.setFechaPrestamo(ahora);
        p.setFechaVencimiento(ahora.plusDays(dto.diasPrestamo()));
        p.setEstado(ACTIVO);
        p.setPersona(u.getPersona());
        Prestamo prestamoGuardado = prestamoRepository.save(p);

        DetallePrestamo d = new DetallePrestamo();
        d.setPrestamo(prestamoGuardado);
        d.setEjemplar(ej);
        detallePrestamoRepository.save(d);

        ej.setEstado("PRESTADO");
        ejemplarRepository.save(ej);

        return convertToDTO(prestamoGuardado);
    }

    @Override
    @Transactional
    public PrestamoDTO devolver(Long idEjemplar) {
        Ejemplar ej = ejemplarRepository.findById(idEjemplar)
                .orElseThrow(() -> new ResourceNotFoundException("Ejemplar no encontrado con id:" + idEjemplar));

        DetallePrestamo d = detallePrestamoRepository.findByEjemplarIdEjemplarAndPrestamoEstado(idEjemplar, ACTIVO)
                .orElseThrow(() -> new BusinessRuleException("No existe un prestamo activo para este ejemplar"));

        Prestamo p = d.getPrestamo();
        p.setEstado(DEVUELTO);
        p.setFechaDevolucion(LocalDateTime.now());
        prestamoRepository.save(p);

        ej.setEstado("DISPONIBLE");
        ejemplarRepository.save(ej);

        return convertToDTO(p);
    }

    @Override
    @Transactional
    public PrestamoDTO renovar(Long idPrestamo, int diasExtension) {
        if (diasExtension < 1 || diasExtension > MAX_DIAS_RENOVACION) {
            throw new IllegalArgumentException("Los dias de extension deben estar entre 1 y " + MAX_DIAS_RENOVACION);
        }
        Prestamo p = prestamoRepository.findById(idPrestamo)
                .orElseThrow(() -> new ResourceNotFoundException("Prestamo no encontrado con id:" + idPrestamo));

        if (!ACTIVO.equals(p.getEstado())) {
            throw new BusinessRuleException("Solo se puede renovar un prestamo activo");
        }
        if (p.getFechaVencimiento().isBefore(LocalDateTime.now())) {
            throw new BusinessRuleException("No se puede renovar un prestamo vencido, debe devolverse primero");
        }

        p.setFechaVencimiento(p.getFechaVencimiento().plusDays(diasExtension));
        return convertToDTO(prestamoRepository.save(p));
    }

    @Override
    @Transactional(readOnly = true)
    public List<PrestamoDTO> listarTodo() {
        return prestamoRepository.findAll().stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<PrestamoDTO> listarVencidos() {
        return prestamoRepository.findByEstadoAndFechaVencimientoBefore(ACTIVO, LocalDateTime.now()).stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<PrestamoDTO> listarPorPersona(Long idPersona) {
        return prestamoRepository.findByPersonaIdPersona(idPersona).stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PrestamoDTO> buscarPorId(Long id) {
        return prestamoRepository.findById(id).map(this::convertToDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DetallePrestamoDTO> listarDetalle(Long idPrestamo) {
        if (!prestamoRepository.existsById(idPrestamo)) {
            throw new ResourceNotFoundException("Prestamo no encontrado con id:" + idPrestamo);
        }
        return detallePrestamoRepository.findByPrestamoIdPrestamo(idPrestamo).stream()
                .map(d -> new DetallePrestamoDTO(
                        d.getIdDetalle(),
                        d.getPrestamo().getIdPrestamo(),
                        d.getEjemplar().getIdEjemplar(),
                        d.getEjemplar().getIsbn(),
                        d.getEjemplar().getLibro().getTitulo()))
                .toList();
    }

    private PrestamoDTO convertToDTO(Prestamo p) {
        return new PrestamoDTO(
                p.getIdPrestamo(),
                p.getFechaPrestamo(),
                p.getFechaVencimiento(),
                p.getFechaDevolucion(),
                p.getEstado(),
                p.getPersona().getIdPersona(),
                p.getPersona().getNombres() + " " + p.getPersona().getApellidos()
        );
    }
}
