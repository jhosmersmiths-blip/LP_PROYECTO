package Crai.crai.services;

import Crai.crai.dto.ControlIngresoDTO;
import Crai.crai.entity.ControlIngreso;
import Crai.crai.entity.Usuario;
import Crai.crai.exception.BusinessRuleException;
import Crai.crai.exception.ResourceNotFoundException;
import Crai.crai.repository.ControlIngresoRepository;
import Crai.crai.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ControlIngresoServiceImpl implements IControlIngresoService {
    private final ControlIngresoRepository controlIngresoRepository;
    private final UsuarioRepository usuarioRepository;

    public ControlIngresoServiceImpl(ControlIngresoRepository controlIngresoRepository, UsuarioRepository usuarioRepository) {
        this.controlIngresoRepository = controlIngresoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ControlIngresoDTO> listarTodo() {
        return controlIngresoRepository.findAll().stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ControlIngresoDTO> listarPorPersona(Long idPersona) {
        return controlIngresoRepository.findByUsuarioIdPersona(idPersona).stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ControlIngresoDTO> buscarPorId(Long id) {
        return controlIngresoRepository.findById(id).map(this::convertToDTO);
    }

    @Override
    @Transactional
    public ControlIngresoDTO registrar(ControlIngresoDTO dto) {
        Usuario u = usuarioRepository.findByCodigoUni(dto.codigoUni())
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con codigo:" + dto.codigoUni()));

        if (u.getEstadoAcceso() == null || u.getEstadoAcceso() != 1) {
            throw new BusinessRuleException("Acceso denegado: el usuario no tiene acceso habilitado");
        }

        // Solo se compara con el ultimo movimiento del dia de hoy
        Optional<ControlIngreso> ultimo = controlIngresoRepository
                .findTopByUsuarioIdPersonaOrderByFechaHoraDesc(u.getIdPersona())
                .filter(c -> c.getFechaHora().toLocalDate().equals(LocalDate.now()));

        boolean estaDentro = ultimo.isPresent() && "ENTRADA".equals(ultimo.get().getTipoAcceso());
        if ("ENTRADA".equals(dto.tipoAcceso()) && estaDentro) {
            throw new BusinessRuleException("El usuario ya se encuentra dentro del CRAI");
        }
        if ("SALIDA".equals(dto.tipoAcceso()) && !estaDentro) {
            throw new BusinessRuleException("El usuario no tiene una entrada registrada hoy");
        }

        ControlIngreso c = new ControlIngreso();
        c.setFechaHora(LocalDateTime.now());
        c.setTipoAcceso(dto.tipoAcceso());
        c.setUsuario(u);
        return convertToDTO(controlIngresoRepository.save(c));
    }

    private ControlIngresoDTO convertToDTO(ControlIngreso c) {
        return new ControlIngresoDTO(
                c.getIdIngreso(),
                c.getFechaHora(),
                c.getTipoAcceso(),
                c.getUsuario().getCodigoUni(),
                c.getUsuario().getPersona().getNombres() + " " + c.getUsuario().getPersona().getApellidos()
        );
    }
}
