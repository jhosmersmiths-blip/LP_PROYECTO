package Crai.crai.services;

import Crai.crai.dto.LibroPrestadoDTO;
import Crai.crai.dto.ResumenDTO;
import Crai.crai.repository.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReporteServiceImpl implements IReporteService {
    private final LibroRepository libroRepository;
    private final EjemplarRepository ejemplarRepository;
    private final UsuarioRepository usuarioRepository;
    private final PrestamoRepository prestamoRepository;
    private final DetallePrestamoRepository detallePrestamoRepository;
    private final ReservaSalaRepository reservaSalaRepository;
    private final ControlIngresoRepository controlIngresoRepository;

    public ReporteServiceImpl(LibroRepository libroRepository, EjemplarRepository ejemplarRepository,
                              UsuarioRepository usuarioRepository, PrestamoRepository prestamoRepository,
                              DetallePrestamoRepository detallePrestamoRepository,
                              ReservaSalaRepository reservaSalaRepository,
                              ControlIngresoRepository controlIngresoRepository) {
        this.libroRepository = libroRepository;
        this.ejemplarRepository = ejemplarRepository;
        this.usuarioRepository = usuarioRepository;
        this.prestamoRepository = prestamoRepository;
        this.detallePrestamoRepository = detallePrestamoRepository;
        this.reservaSalaRepository = reservaSalaRepository;
        this.controlIngresoRepository = controlIngresoRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public ResumenDTO resumen() {
        LocalDate hoy = LocalDate.now();
        LocalDateTime inicioDia = hoy.atStartOfDay();
        return new ResumenDTO(
                libroRepository.count(),
                ejemplarRepository.count(),
                ejemplarRepository.countByEstado("DISPONIBLE"),
                usuarioRepository.count(),
                prestamoRepository.countByEstado("A"),
                prestamoRepository.countByEstadoAndFechaVencimientoBefore("A", LocalDateTime.now()),
                reservaSalaRepository.countByFechaReservaAndEstado(hoy, "A"),
                controlIngresoRepository.countByFechaHoraBetween(inicioDia, inicioDia.plusDays(1))
        );
    }

    @Override
    @Transactional(readOnly = true)
    public List<LibroPrestadoDTO> librosMasPrestados(int limite) {
        if (limite < 1 || limite > 50) {
            throw new IllegalArgumentException("El limite debe estar entre 1 y 50");
        }
        return detallePrestamoRepository.librosMasPrestados(PageRequest.of(0, limite));
    }
}
