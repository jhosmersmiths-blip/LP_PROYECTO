package Crai.crai.services;

import Crai.crai.dto.LibroPrestadoDTO;
import Crai.crai.dto.ResumenDTO;

import java.util.List;

public interface IReporteService {
    ResumenDTO resumen();
    List<LibroPrestadoDTO> librosMasPrestados(int limite);
}
