package Crai.crai.entity;

public enum Rol {
    ADMIN,
    ESTUDIANTE,
    DOCENTE
}
