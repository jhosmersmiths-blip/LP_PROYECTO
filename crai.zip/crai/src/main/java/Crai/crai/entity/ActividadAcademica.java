package Crai.crai.entity;

public enum ActividadAcademica {
    INVESTIGACION,   // Investigación académica
    MATEMATICAS,     // Práctica de matemáticas y resolución de ejercicios
    EXPOSICION,      // Preparación y práctica de una exposición
    ESTUDIO_GRUPAL,  // Estudio grupal y repaso de cursos
    TRABAJOS,        // Desarrollo de trabajos académicos
    EXAMENES         // Preparación para exámenes
}
