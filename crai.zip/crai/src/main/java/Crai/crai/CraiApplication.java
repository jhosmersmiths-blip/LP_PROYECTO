package Crai.crai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CraiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CraiApplication.class, args);
	}

}
