package Crai.crai.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI customOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("API CRAI - Centro de Recursos para el Aprendizaje y la Investigacion")
                        .version("1.0")
                        .description("Gestion de libros, ejemplares, prestamos, ingresos y reserva de salas")
                );
    }
}
