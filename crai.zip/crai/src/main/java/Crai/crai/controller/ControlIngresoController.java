package Crai.crai.controller;

import Crai.crai.dto.ControlIngresoDTO;
import Crai.crai.exception.ResourceNotFoundException;
import Crai.crai.services.IControlIngresoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/ingresos")
public class ControlIngresoController {
    private final IControlIngresoService controlIngresoService;

    public ControlIngresoController(IControlIngresoService controlIngresoService) {
        this.controlIngresoService = controlIngresoService;
    }

    @GetMapping
    public ResponseEntity<List<ControlIngresoDTO>> listar() {
        return ResponseEntity.ok(controlIngresoService.listarTodo());
    }

    @GetMapping("/persona/{idPersona}")
    public ResponseEntity<List<ControlIngresoDTO>> listarPorPersona(@PathVariable Long idPersona) {
        return ResponseEntity.ok(controlIngresoService.listarPorPersona(idPersona));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ControlIngresoDTO> obtener(@PathVariable Long id) {
        return controlIngresoService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new ResourceNotFoundException("Registro de ingreso no encontrado con id:" + id));
    }

    @PostMapping
    public ResponseEntity<ControlIngresoDTO> registrar(@Valid @RequestBody ControlIngresoDTO dto) {
        return new ResponseEntity<>(controlIngresoService.registrar(dto), HttpStatus.CREATED);
    }
}
