package Crai.crai.controller;

import Crai.crai.dto.LibroPrestadoDTO;
import Crai.crai.dto.ResumenDTO;
import Crai.crai.services.IReporteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reportes")
public class ReporteController {
    private final IReporteService reporteService;

    public ReporteController(IReporteService reporteService) {
        this.reporteService = reporteService;
    }

    // Indicadores generales del CRAI
    @GetMapping("/resumen")
    public ResponseEntity<ResumenDTO> resumen() {
        return ResponseEntity.ok(reporteService.resumen());
    }

    @GetMapping("/libros-mas-prestados")
    public ResponseEntity<List<LibroPrestadoDTO>> librosMasPrestados(@RequestParam(defaultValue = "5") int limite) {
        return ResponseEntity.ok(reporteService.librosMasPrestados(limite));
    }
}
