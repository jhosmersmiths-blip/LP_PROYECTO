package Crai.crai.controller;

import Crai.crai.dto.DetallePrestamoDTO;
import Crai.crai.dto.PrestamoDTO;
import Crai.crai.dto.PrestamoRegistroDTO;
import Crai.crai.exception.ResourceNotFoundException;
import Crai.crai.services.IPrestamoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/prestamos")
public class PrestamoController {
    private final IPrestamoService prestamoService;

    public PrestamoController(IPrestamoService prestamoService) {
        this.prestamoService = prestamoService;
    }

    @GetMapping
    public ResponseEntity<List<PrestamoDTO>> listar() {
        return ResponseEntity.ok(prestamoService.listarTodo());
    }

    @GetMapping("/vencidos")
    public ResponseEntity<List<PrestamoDTO>> listarVencidos() {
        return ResponseEntity.ok(prestamoService.listarVencidos());
    }

    @GetMapping("/persona/{idPersona}")
    public ResponseEntity<List<PrestamoDTO>> listarPorPersona(@PathVariable Long idPersona) {
        return ResponseEntity.ok(prestamoService.listarPorPersona(idPersona));
    }

    @GetMapping("/{id}")
    public ResponseEntity<PrestamoDTO> obtener(@PathVariable Long id) {
        return prestamoService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new ResourceNotFoundException("Prestamo no encontrado con id:" + id));
    }

    @GetMapping("/{id}/detalle")
    public ResponseEntity<List<DetallePrestamoDTO>> listarDetalle(@PathVariable Long id) {
        return ResponseEntity.ok(prestamoService.listarDetalle(id));
    }

    @PostMapping("/registrar")
    public ResponseEntity<PrestamoDTO> registrar(@Valid @RequestBody PrestamoRegistroDTO dto) {
        return new ResponseEntity<>(prestamoService.registrar(dto), HttpStatus.CREATED);
    }

    @PutMapping("/devolucion")
    public ResponseEntity<PrestamoDTO> devolucion(@RequestParam Long idEjemplar) {
        return ResponseEntity.ok(prestamoService.devolver(idEjemplar));
    }

    @PutMapping("/{id}/renovar")
    public ResponseEntity<PrestamoDTO> renovar(@PathVariable Long id, @RequestParam int diasExtension) {
        return ResponseEntity.ok(prestamoService.renovar(id, diasExtension));
    }
}
