package Crai.crai.repository;

import Crai.crai.entity.ReservaIntegrante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReservaIntegranteRepository extends JpaRepository<ReservaIntegrante, Long> {
    List<ReservaIntegrante> findByReservaSalaIdReservaSala(Long idReservaSala);
    long countByReservaSalaIdReservaSala(Long idReservaSala);
    boolean existsByReservaSalaIdReservaSalaAndCodigoUni(Long idReservaSala, String codigoUni);
    void deleteByReservaSalaIdReservaSala(Long idReservaSala);
}
