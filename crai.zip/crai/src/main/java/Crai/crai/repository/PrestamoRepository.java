package Crai.crai.repository;

import Crai.crai.entity.Prestamo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface PrestamoRepository extends JpaRepository<Prestamo, Long> {
    List<Prestamo> findByPersonaIdPersona(Long idPersona);
    List<Prestamo> findByEstado(String estado);
    List<Prestamo> findByEstadoAndFechaVencimientoBefore(String estado, LocalDateTime fecha);
    long countByEstado(String estado);
    long countByEstadoAndFechaVencimientoBefore(String estado, LocalDateTime fecha);
    long countByPersonaIdPersonaAndEstado(Long idPersona, String estado);
    boolean existsByPersonaIdPersonaAndEstadoAndFechaVencimientoBefore(Long idPersona, String estado, LocalDateTime fecha);
}
