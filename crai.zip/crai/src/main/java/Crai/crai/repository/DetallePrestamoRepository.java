package Crai.crai.repository;

import Crai.crai.dto.LibroPrestadoDTO;
import Crai.crai.entity.DetallePrestamo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DetallePrestamoRepository extends JpaRepository<DetallePrestamo, Long> {
    List<DetallePrestamo> findByPrestamoIdPrestamo(Long idPrestamo);
    Optional<DetallePrestamo> findByEjemplarIdEjemplarAndPrestamoEstado(Long idEjemplar, String estado);

    @Query("SELECT new Crai.crai.dto.LibroPrestadoDTO(l.idLibro, l.titulo, COUNT(d)) " +
            "FROM DetallePrestamo d JOIN d.ejemplar e JOIN e.libro l " +
            "GROUP BY l.idLibro, l.titulo " +
            "ORDER BY COUNT(d) DESC")
    List<LibroPrestadoDTO> librosMasPrestados(Pageable pageable);
}
