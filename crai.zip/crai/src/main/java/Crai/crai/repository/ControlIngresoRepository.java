package Crai.crai.repository;

import Crai.crai.entity.ControlIngreso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ControlIngresoRepository extends JpaRepository<ControlIngreso, Long> {
    List<ControlIngreso> findByUsuarioIdPersona(Long idPersona);
    Optional<ControlIngreso> findTopByUsuarioIdPersonaOrderByFechaHoraDesc(Long idPersona);
    long countByFechaHoraBetween(LocalDateTime desde, LocalDateTime hasta);
}
