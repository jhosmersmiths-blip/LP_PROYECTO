package Crai.crai.dto;

public record EstudianteValidadoDTO(
        String codigoUni,

        String nombrePersona,

        String escuela
) {
}
