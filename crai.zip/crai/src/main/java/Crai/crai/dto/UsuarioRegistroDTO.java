package Crai.crai.dto;

import Crai.crai.entity.Rol;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record UsuarioRegistroDTO(
        @NotBlank(message = "el nombre es obligatorio")
        String nombres,

        @NotBlank(message = "el apellido es obligatorio")
        String apellidos,

        @NotBlank(message = "el email es obligatorio")
        @Email(message = "debe ser un email valido")
        String email,

        @NotBlank(message = "el codigo universitario es obligatorio")
        String codigoUni,

        @NotBlank(message = "el usuario es obligatorio")
        @Size(min = 4, max = 20, message = "el usuario debe tener entre 4 y 20 caracteres")
        String username,

        @NotNull(message = "el rol es obligatorio")
        Rol rol,

        Long idEscuelaProf
) {
}
