package Crai.crai.dto;

public record LibroPrestadoDTO(
        Long idLibro,

        String titulo,

        Long totalPrestamos
) {
}
